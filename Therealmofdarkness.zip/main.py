from mine import *
from Past import *
from maze import *
import pickle
a1()
n = input("Hello *says a cheery voice* What is your name? \n")
import random

options = ["the realm of darkness", "the realm of the past"]
weights = [99, 1,]
chosen_world = random.choices(options, weights=weights, k=1)[0]
print("*The door speaks to you* hello, " + n + f" you have been transported to {chosen_world}.\n")
if chosen_world == "the realm of the past":
    past()

if chosen_world == "the realm of darkness":
    save = input("do you have save data? \n")
    if save == "yes":
        with open("savegame.dat", "rb") as file:
            inventory = pickle.load(file)
            coins = pickle.load(file)
            coinbag = pickle.load(file)
            amulet = pickle.load(file)
            boots = pickle.load(file)
            glasses = pickle.load(file)
            Watch = pickle.load(file)
            Map = pickle.load(file)
        print("You have these items in your inventory:", str(inventory) + " and ", str(coins) + " coins.\n")
    else:
        print("\n")
    print("""Welcome to...
    
████████╗██╗░░██╗███████╗  ██████╗░███████╗░█████╗░██╗░░░░░███╗░░░███╗  ░█████╗░███████╗  ██████╗░░█████╗░██████╗░██╗░░██╗███╗░░██╗███████╗░██████╗░██████╗
╚══██╔══╝██║░░██║██╔════╝  ██╔══██╗██╔════╝██╔══██╗██║░░░░░████╗░████║  ██╔══██╗██╔════╝  ██╔══██╗██╔══██╗██╔══██╗██║░██╔╝████╗░██║██╔════╝██╔════╝██╔════╝
░░░██║░░░███████║█████╗░░  ██████╔╝█████╗░░███████║██║░░░░░██╔████╔██║  ██║░░██║█████╗░░  ██║░░██║███████║██████╔╝█████═╝░██╔██╗██║█████╗░░╚█████╗░╚█████╗░
░░░██║░░░██╔══██║██╔══╝░░  ██╔══██╗██╔══╝░░██╔══██║██║░░░░░██║╚██╔╝██║  ██║░░██║██╔══╝░░  ██║░░██║██╔══██║██╔══██╗██╔═██╗░██║╚████║██╔══╝░░░╚═══██╗░╚═══██╗
░░░██║░░░██║░░██║███████╗  ██║░░██║███████╗██║░░██║███████╗██║░╚═╝░██║  ╚█████╔╝██║░░░░░  ██████╔╝██║░░██║██║░░██║██║░╚██╗██║░╚███║███████╗██████╔╝██████╔╝
░░░╚═╝░░░╚═╝░░╚═╝╚══════╝  ╚═╝░░╚═╝╚══════╝╚═╝░░╚═╝╚══════╝╚═╝░░░░░╚═╝  ░╚════╝░╚═╝░░░░░  ╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝╚══════╝╚═════╝░╚═════╝░
\n""")
    slow_print("You enter a dark cave with the only light source you see being the torch on the wall.\n")
    slow_print("You go and grab the torch from it's weak uncared for clasp that has excessive rust on it.\n")
    slow_print("The cobwebs confirm your concerns, no one has been here for a while.\n")
    slow_print("Enter the option you see exactly caps sensitive.\n")
    aa = input("""You follow the corridor looking for a way out. You come to a rickety-looking bridge spanning over a large chasm. what do you do?
    Trust the bridge
    Look for another way out
    
    \n""")
    actions = ["Trust the bridge", "Look for another way out"]
    while aa not in actions:
        slow_print("Please enter a valid option for the adventure game.\n")
        aa = input("""You follow the corridor looking for a way out. You come to a rickety-looking bridge spanning over a large chasm. what do you do?
    Trust the bridge
    Look for another way out
    
    \n""")
    if aa == "Trust the bridge":
        slow_print("You walk across the bridge and it caves in on itself.\n")
        import time
        slow_print("And then you fall...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        slow_print("A fairy approaches you\n")
        ab = input("\"You're still here?\" \n")
        slow_print("The fairy leaves\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        time.sleep(4)
        slow_print("and keep falling...\n")
        slow_print("You see a light at the bottom of the chasm.\n")
        time.sleep(4)
        slow_print("You are almost to the light\n")
        time.sleep(4)
        slow_print("You come out the other side of the chasm and find that the tunnel leads to the chasm you fell into.\n")
        slow_print("You found a secret!\n")

        slow_print("Acheivement got. send screenshot to Noah Ross.\n")
        slow_print("UNLOCKED: pure patience questline\n")
        ac = input("Enter your first and last name here for it to be valid: \n")

    elif aa == "Look for another way out":
        if Map == 1:
        
            slow_print("You turn back and enter a different, less obvious passage. You find a map on the floor\n")
            slow_print("Enter yes or no with no caps\n")
            ad = input("Pick up the map? \n")
            actions = ["yes", "no"]
            while ad not in actions:
                slow_print("Please enter a valid option for the adventure game.\n")
                ad = input("Pick up the map? \n")
            if ad == "yes":
                slow_print("You pick up the map and look at it.\n")
                
                Map -=1
                inventory.append("Map")
                print("""       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │          X                       │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │                │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘      \n""")
                slow_print("You piece together that this is a magic map. S = where you started   # = the bridge  X = You   * = ??\n")
                maproom()
        if ad == "no":
            print("After you pass up the map you realise it has sentience as it chokes you to death\n")
    else:
        slow_print("Please enter a valid option for the adventure game.\n")