def past():
    slow_print("You have been transfered to a world that is back in time\n")
    slow_print(" \n")
    print("""Welcome to...
    ████████╗██╗░░██╗███████╗  ██████╗░██████╗░░█████╗░░██████╗░░█████╗░███╗░░██╗  ░█████╗░███╗░░██╗██████╗░  ████████╗██╗░░██╗███████╗  ░██╗░░░░░░░██╗░█████╗░██████╗░██████╗░██╗░█████╗░██████╗░
    ╚══██╔══╝██║░░██║██╔════╝  ██╔══██╗██╔══██╗██╔══██╗██╔════╝░██╔══██╗████╗░██║  ██╔══██╗████╗░██║██╔══██╗  ╚══██╔══╝██║░░██║██╔════╝  ░██║░░██╗░░██║██╔══██╗██╔══██╗██╔══██╗██║██╔══██╗██╔══██╗
    ░░░██║░░░███████║█████╗░░  ██║░░██║██████╔╝███████║██║░░██╗░██║░░██║██╔██╗██║  ███████║██╔██╗██║██║░░██║  ░░░██║░░░███████║█████╗░░  ░╚██╗████╗██╔╝███████║██████╔╝██████╔╝██║██║░░██║██████╔╝
    ░░░██║░░░██╔══██║██╔══╝░░  ██║░░██║██╔══██╗██╔══██║██║░░╚██╗██║░░██║██║╚████║  ██╔══██║██║╚████║██║░░██║  ░░░██║░░░██╔══██║██╔══╝░░  ░░████╔═████║░██╔══██║██╔══██╗██╔══██╗██║██║░░██║██╔══██╗
    ░░░██║░░░██║░░██║███████╗  ██████╔╝██║░░██║██║░░██║╚██████╔╝╚█████╔╝██║░╚███║  ██║░░██║██║░╚███║██████╔╝  ░░░██║░░░██║░░██║███████╗  ░░╚██╔╝░╚██╔╝░██║░░██║██║░░██║██║░░██║██║╚█████╔╝██║░░██║
    ░░░╚═╝░░░╚═╝░░╚═╝╚══════╝  ╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░╚═════╝░░╚════╝░╚═╝░░╚══╝  ╚═╝░░╚═╝╚═╝░░╚══╝╚═════╝░  ░░░╚═╝░░░╚═╝░░╚═╝╚══════╝  ░░░╚═╝░░░╚═╝░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░╚════╝░╚═╝░░╚═╝
    
    Coded by...
    █▄░█ █▀█ ▄▀█ █░█   █▀█ █▀█ █▀ █▀
    █░▀█ █▄█ █▀█ █▀█   █▀▄ █▄█ ▄█ ▄█
    """)
    
    
    slow_print ("It is a cold harsh night\n")
    slow_print ("an adventurer enters a dark cave with a singular goal in mind.\n")
    slow_print ("He hears the stomps of the godly dragon's footsteps and realizes that the rumors were true.\n")
    slow_print ("the booming voice shakes you to your very core.\n")
    name= input("ᴡʜᴀᴛ ɪꜱ ʏᴏᴜʀ ɴᴀᴍᴇ ᴍᴏʀᴛᴀʟ? \n")
    if name == "Noah Ross":
        slow_print("Welcome master I aim to please you in all that I do.\n")
        slow_print("YOU FOUND A SECRET\n")
    else:
        slow_print ("""
        Type objective exactly:
        To defeat you
        To ask of a godly gift
        To seek shelter on this cold night
         """)
        
        
        a = input("ᴡʜʏ ʜᴀᴠᴇ ʏᴏᴜ ᴀᴘᴘʀᴏᴀᴄʜᴇᴅ ᴍᴇ ᴛʜɪꜱ ɴɪɢʜᴛ? \n")
        
        
        b = input("ʏᴏᴜ ᴄᴏᴍᴇ ɪɴᴛᴏ ᴍʏ ᴄʜᴀᴍʙᴇʀꜱ ᴛᴏ ꜰᴇᴇᴅ ʏᴏᴜʀ ɢʟᴜᴛᴛᴏɴᴏᴜꜱ ᴅᴇꜱɪʀᴇꜱ "+ name+"? (type yes or no) \n")
        if b == "yes":
            slow_print ("YOU DIED\n")
        if b == "no":
            slow_print ("""ɪ ꜱʜᴀʟʟ ʟᴇᴛ ʏᴏᴜ ꜱᴛᴀʏ ᴛᴏɴɪɢʜᴛ. ʙᴜᴛ ɪꜰ ʏᴏᴜ ᴅᴀʀᴇ ᴇɴᴛᴇʀ ᴛʜᴇ ᴍᴀɪɴ ᴄʜᴀᴍʙᴇʀꜱ, ɪ ᴡɪʟʟ ꜱʟᴀʏ ʏᴏᴜ.
            """)
            if a == "To defeat you":
                slow_print ("""ʜᴏᴡᴇᴠᴇʀ, ɪ ᴀᴍ ʀᴇᴛʜɪɴᴋɪɴɢ. ɪꜰ ʏᴏᴜ ᴘʟᴀɴ ᴛᴏ ꜱʟᴀʏ ᴍᴇ ʙʀᴀᴠᴇ ᴡᴀʀʀɪᴏʀ. ɪ ᴡɪʟʟ ʀᴇᴛᴜʀɴ ᴛʜᴇ ꜰᴀᴠᴏʀ.
                    YOU DIED""")
            if a == "To ask of a godly gift":
                    d = input("ɪ ᴀᴍ ɢʟᴏʀɪᴇᴅ ᴏꜰ ʏᴏᴜʀ ᴡᴏʀꜱʜɪᴘ, ʜᴏᴡᴇᴠᴇʀ, ɪ ᴘᴏꜱᴇꜱꜱ ɴᴏ ꜱᴜᴄʜ ᴘᴏᴡᴇʀꜱ, ᴜɴʟᴇꜱꜱ ᴛʜᴇ ɢɪꜰᴛ ʏᴏᴜ ᴡᴏᴜʟᴅ ʟɪᴋᴇ ᴛᴏ ʀᴇᴄɪᴇᴠᴇ ɪꜱ ᴍʏ ɢᴏʟᴅ? \n")
                    if d == "yes":
                       print("""ꜰᴏᴏʟɪꜱʜ ᴅᴇᴄɪꜱɪᴏɴ.
                    YOU DIED""")
                    if d == "no":
                        slow_print ("ɢᴏᴏᴅ ᴅᴇᴄɪꜱɪᴏɴ. ɪ ɴᴏᴡ ᴛʀᴜꜱᴛ ʏᴏᴜ ɪɴ ᴍʏ ɢʀᴇᴀᴛ ᴄʜᴀᴍʙᴇʀꜱ.\n")
                        c = input("The dragon has gone to rest. dare you enter the main chambers? \n")
                        if c == "yes":
                            slow_print ("you enter and see mounds and mounds of gold but have the feeling that you shouldn't take it.\n")
                            st = input("Would you like to continue straight? \n")
                            if st == "yes":
                                slow_print("You go straight and come to a locked door\n")
                                slow_print("You turn back and are crushed by a falling pile of gold\n")
                                slow_print("YOU DIED\n")
                            if st == "no":
                                f = input("would you like to go left or right? \n")
                                if f == "left":
                                    print("""You walk into the left chambers and stumble right onto the dragon's tail.
                                    ʜᴏᴡ ᴅᴀʀᴇ ʏᴏᴜ ᴅɪꜱᴏʙᴇʏ ᴍʏ ᴅɪʀᴇᴄᴛ ᴏʀᴅᴇʀꜱ
                                    YOU DIED""")
                                
                                if f == "right":
                                    slow_print("You go to the right and find the servents chambers. One of the servents comes out of his room and spots you.\n")
                                    g = input("""what do you do?
                                    Attack
                                    Run
                                    Engage in conversation
                                     
                                    """)
                                    if g == "Attack":
                                        slow_print("Although your opponent seems scrawny, he seems to be reading your mind and predicting your moves. he defeats you easily\n")
                                        print("YOU DIED\n")
                                    if g == "Run":
                                        print("""You run back the way you came. take a wrong turn and run right into the dragons den
                                        YOU DIED""")
                                    if g == "Engage in conversation":
                                        slow_print("You engage him in conversation but he is reading your mind. \"Hello, " + name + " It is desirable that you didn't run. master gets angry when people disobey his orders, not only would he have killed you but he would have also injured a devout servant\"\n")
                                        slow_print("The voice seems directly projected into your mind, It is echoey and lingers ever so slightly.\n")
                                        slow_print("\"Run " + name + "\" he says projecting it into your mind. \"Go down into the great hall.\n")
                                        slow_print("\"And take this as well\" he hands you a mysterious key.\n")
                                        slow_print("you start running and look back because you forgot to thank the man.\n")
                                        slow_print("all you see is a misty outline where the man was\n")
                                        slow_print("*YOU NOW HAVE THE ABILITY TO GO STRAIGHT*\n")
                                        slow_print("You travel back to the door and insert the key.\n")
                                        slow_print("The door opens with a stone upon stone grinding noise\n")
                                        slow_print("you underestimated what would be on the other side of the door and are completely blown away when you see a portal to another world\n")
                                        slow_print(" \n")
                                        slow_print("to be continued\n")
                                        slow_print("once done with this one send a screenshot to prove it and I will send you the next part\n")
                        
                        
                        
                        
                        if c == "no":
                            print("""you go and rest on the floor waiting for tomorrow.
                            In the morning after giving thanks to the dragon, you enter the town aching from sleeping on the floor. you remember the town well, little has changed since your last visit. You go to the bakery you remember fondly and find your mother there. \" your father has died.\" after a few days you recover and realize that you can seek the gifts of the dragon and go on your quest. *later that night*
                            It is a cold harsh night...
                            GAME OVER 2nd true ending""")
                    
                    
                    
                    
            if a == "To seek shelter on this cold night":
                e = input("ɪ ᴀᴘᴘʟᴀᴜᴅ ʏᴏᴜʀ ʙʀᴀᴠᴇʀʏ, ʙᴜᴛ ᴡɪʟʟ ᴏɴʟʏ ᴀᴄᴄᴇᴘᴛ ʏᴏᴜ ɪꜰ ʏᴏᴜ ʙᴇᴄᴏᴍᴇ ᴀ ᴡᴏʀᴋᴇʀ ꜰᴏʀ ᴍʏ ᴠᴀʀɪᴏᴜꜱ    ꜱᴛᴜᴅɪᴇꜱ ᴏꜰ ᴛʜɪꜱ ᴘʟᴀɴᴇᴛ. ᴡɪʟʟ ʏᴏᴜ? you will not be allowed to leave. \n")
                if e == "yes":
                    slow_print ("ɪ ᴡɪʟʟ ᴛᴀᴋᴇ ʏᴏᴜ ᴛᴏ ʏᴏᴜʀ ᴄʜᴀᴍʙᴇʀꜱ, ᴛʜʀᴏᴜɢʜ ʜᴀʀᴅ ᴡᴏʀᴋ ᴀɴᴅ ᴅᴇᴅɪᴄᴀᴛɪᴏɴ ʏᴏᴜ ᴍᴀʏ ʙᴇ ᴀʙʟᴇ ᴛᴏ ɢᴀɪɴ ᴀ ʜɪɢʜᴇʀ ʀᴀɴᴋ. ᴛʜᴇʀꜰᴏʀᴇ ɢᴀɪɴɪɴɢ ᴀ ʙᴇᴛᴛᴇʀ ʀᴏᴏᴍ.\n")
                    slow_print ("GAME OVER 1st true ending.\n")
                if e == "no":
                    print("""ʏᴏᴜ ᴀʀᴇ ᴀ ʙʀᴀᴠᴇ ᴏɴᴇ, ʙᴜᴛ ʙʀᴀᴠᴇʀʏ ᴅᴏᴇꜱɴ'ᴛ ᴀʟᴡᴀʏꜱ ᴍᴇᴀɴ ꜱᴍᴀʀᴛ
                    after you were kicked out you realize that you underestimated the cold.
                    YOU DIED""")