from maze import a1
import pickle
import time
def  slow_print(text):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.03)
inventory = ["Torch"]
coins = 0
coinbag = 1
amulet = 1
boots = 1
glasses = 1
Watch = 1
Map = 1
def maproom():
  directions = ["left", "right"]
  print("""You are in The room where you found the map. You can go forwards to a new room or backwards to the bridge room.
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │          X                       │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │                │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘      \n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/right\n")
    userInput = input()
    if userInput == "left":
      bridgeroom()
    elif userInput == "right":
      nothing()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")


def bridgeroom():
  directions = ["to start", "right"]
  print("""You are back in the room with the sketchy looking bridge. you avoid it.
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │                                  │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########  X  │       |        │            
       │     │                │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘      \n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: to start/right\n")
    userInput = input()
    if userInput == "to start":
      startroom()
    elif userInput == "right":
      maproom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def nothing():
  directions = ["left", "right", "down"]
  print("""You have entered a room with a three way. you can go backward forward or right
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │                  X               │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │                │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘      \n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/right/down\n")
    userInput = input()
    if userInput == "left":
      maproom()
    elif userInput == "right":
      tallroom()
    elif userInput == "down":
      squareroom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")


def startroom():
  directions = ["left"]
  print("""You are in the room where the door first transported you to.
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │                                  │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │                │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐  X     │      
                           │        │      
                           └────────┘      \n""")
  global coinbag
  if coinbag > 0:
    coinbag -= 1
    slow_print("You find a small pouch with 10 coins of foreign currency inside in the corner of the room and pick it up.\n")
    global coins
    coins += 10
    slow_print("You now have " + str(coins) + " coins in your pouch\n")
    with open("savegame.dat", "wb") as file:
        pickle.dump(inventory, file)
        pickle.dump(coins, file)
        pickle.dump(coinbag, file)
        pickle.dump(amulet, file)
        pickle.dump(boots, file)
        pickle.dump(glasses, file)
        pickle.dump(Watch, file)
        pickle.dump(Map, file)
  else:
      slow_print("You wonder why you returned to this room again? nothing useful here.\n")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left\n")
    userInput = input()
    if userInput == "left":
      bridgeroom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def squareroom():
  directions = ["up", "left"]
  print("""You are in a room with several empty supply shelves. You can go backward or right
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │                                  │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │           X    │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘      \n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: up/left\n")
    userInput = input()
    if userInput == "up":
      nothing()
    elif userInput == "left":
      utahroom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def utahroom():
  directions = ["right"]
  print("""You are in a room which is a large utah shape.
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │                                  │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │    X           │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘      \n""")
  global Watch
  if Watch == 1:
    watch = input("You see a stopwatch on the floor o you want to pick up the watch? \n")
    if watch == "yes":
        inventory.append("Watch")
        with open("savegame.dat", "wb") as file:
            pickle.dump(inventory, file)
            pickle.dump(coins, file)
            pickle.dump(coinbag, file)
            pickle.dump(amulet, file)
            pickle.dump(boots, file)
            pickle.dump(glasses, file)
            pickle.dump(Watch, file)
            pickle.dump(Map, file)
        Watch -= 1
    if watch == "No":
          slow_print("You dismiss the watch and continue on your way\n")
  else:
      print("You found the stopwatch in this room earlier\n")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right\n")
    userInput = input()
    if userInput == "right":
        squareroom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def tallroom():
  directions = ["left", "right"]
  print("""You are in a long room. Nothing else interesting here.
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │                         X        │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │                │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘      \n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/right\n")
    userInput = input()
    if userInput == "left":
      nothing()
    elif userInput == "right":
      dangeroom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def dangeroom():
  directions = ["left", "up"]
  print("""You are in a room scared of what might be ahead because of the map's markings.
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   *  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │                               X  │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │                │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘      \n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up\n")
    userInput = input()
    if userInput == "left":
      tallroom()
    elif userInput == "up":
      traproom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def traproom():
  actions = ["use item", "exit room quickly"]
  global weapon
  print("""You come into the next room and hear the sliding of stone as you step on a pressure plate
       ┌──────────────────────────────────┐
       │      *                      *    │
           *       *  *      *       *    │
       │               *           *   X  │
       ├──────┬──────┬────────┬─────┬──  ─┤
       │      │      |        |     │     │
       │                                  │
       │      |      |        |     │     │
       │     ┌┴──────┼───  ───┼─────┴─────┘
########     │       |        │            
       │     │                │            
       │     └──┐    |        ├─────┐      
       │     ┌┐ └────┴────────┘     │      
       │     ││                 S   │      
       └─────┘└────────────┐        │      
                           │        │      
                           └────────┘\n""")
  userInput = ""
  while userInput not in actions:
    slow_print("Options: use item/exit room quickly\n")
    userInput = input()
    if userInput == "use item":
        if "Watch" in inventory:
            slow_print("You click the stopwatch and freeze time in the process freezing the spiked cieling that would've crushed you\n")
            slow_print("You exit the trapped room as quickly as you can. after exiting finally getting outside, you truly realise why it is called The Realm of Darkness.\n")
            slow_print("The land around you isn't just dark, it absorbs the light around you, quickly putting out your torch\n")
            slow_print("You wander around aimlessly trying to find something in the darkness... anything.\n")
            slow_print("You eventually run directly into a wall and walk along it untill you find a door.\n")
            slow_print("You come into a shop with a shady-looking salesman at the counter.\n")
            slow_print("\"Would you like to buy my wares?\" He says\n")
            global coins
            slow_print("You have " + str(coins) + " coins in your pouch.\n")
            print("""
            Boots
            Amulet
            Glasses
            Nothing\n""")
            print("Before I show you my wares. I reccomend you don't try buying anything you can't afford or anything you already have. The results are rather... unpleasent\n")
            print("You check your inventory unsettled by his message\n")
            print("Items in inventory:", ", ".join(inventory) if inventory else "Empty\n")
            buy = input("Would you like to buy boots to allow you to walk in the toxic mud for 20 coins, an amulet of power for 100 coins, glasses to allow you to see in this darkness for 10 coins, or nothing?\n")
            actions = ["Boots", "Amulet", "Glasses", "Nothing"]
            while buy not in actions:
                slow_print("Please enter a valid option for the adventure game.\n")
                buy = input("Would you like to buy boots to allow you to walk in the toxic mud for 20 coins, an amulet of power for 100 coins, glasses to allow you to see in this darkness for 10 coins, or nothing? You are only allowed one item per visit, so choose wisely.\n")
            if buy == "Boots":
                global boots
                if boots == 1:
                    if coins > 19:
                        inventory.append("Boots\n")
                        boots -=1
                        slow_print("You try on the boots and find that they fit perfectly. You discard your old shoes because they are severely worn\n")
                        coins -= 20
                    else:
                        slow_print("\"I SAID DON\'T BUY IT IF YOU CANNOT AFFORD IT!!!\" *he says as his face unfolds revealing the monster beneath* \n YOU DIED \n")
                else:
                    slow_print("\"I SAID DON\'T BUY IT IF IT IS NOT IN STOCK!!!\" *he says as his face unfolds revealing the monster beneath* \n YOU DIED \n")
            if buy == "Amulet":
                global amulet
                if amulet == 1:
                    if coins > 99:
                        inventory.append("Amulet\n")
                        amulet -=1
                        slow_print("You try on the Amulet and feel a wash of power flow over your body\n")
                        coins -= 100
                    else:
                        slow_print("\"I SAID DON\'T BUY IT IF YOU CANNOT AFFORD IT!!!\" *he says as his face unfolds revealing the monster beneath* \n YOU DIED \n")
                else:
                    slow_print("\"I SAID DON\'T BUY IT IF IT IS NOT IN STOCK!!!\" *he says as his face unfolds revealing the monster beneath* \n YOU DIED \n")
            if buy == "Glasses":
                global glasses
                if glasses == 1:
                    if coins > 9:
                        inventory.append("glasses")
                        glasses -= 1
                        coins -= 10                                    
                        slow_print("You try on the Glasses and look out the window and find that it is not dark at all. you can see everything as if you were looking outside on a clear sunny day\n")
                        with open("savegame.dat", "wb") as file:
                            pickle.dump(inventory, file)
                            pickle.dump(coins, file)
                            pickle.dump(coinbag, file)
                            pickle.dump(amulet, file)
                            pickle.dump(boots, file)
                            pickle.dump(glasses, file)
                            pickle.dump(Watch, file)
                        print(inventory)
                    else:
                        slow_print("\"I SAID DON\'T BUY IT IF YOU CANNOT AFFORD IT!!!\" *he says as his face unfolds revealing the monster beneath* \n YOU DIED \n")
                else:
                    slow_print("\"I SAID DON\'T BUY IT IF IT IS NOT IN STOCK!!!\" *he says as his face unfolds revealing the monster beneath* \n YOU DIED \n")
            
            if "glasses" in inventory:
                slow_print("You walk out into the now clear landscape and feel a rumbling in your pocket.\n")
                slow_print("The map is talking to you. it guides you to a wall covered in vines and finds a tube\n")
                slow_print("You feel as if there is air flowing into the tube and are sucked in as the force becomes to great to  resist.\n")
                slow_print("You fall into a pit with no seeming way back.")
                slow_print("The map tells you that you are in a maze and that he remembers this place.\n")
                a1()
            else:    
                slow_print("You recieve guidance from the map leading to what feels like a viny wall. you are sucked in.\n")
                slow_print("\n")
                slow_print("I am in the process of coding this part so be patient\n")
                a1()
            quit()
        elif "Watch" not in inventory:
            slow_print("You were crushed by the falling spiked cieling\n")
            quit()
    elif userInput == "exit room quickly":
      dangeroom()
    else:
      slow_print("Please enter a valid option for the adventure game.\n")