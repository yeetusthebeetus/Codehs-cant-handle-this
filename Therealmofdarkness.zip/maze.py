def a1():
  directions = ["right"]
  print("You are in the room and find no viable way out. The map tells you to look everywhere because there are \"secrets everywhere\"")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
   X   │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right\n")
    userInput = input()
    if userInput == "right":
      a2()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a2():
  directions = ["down"]
  print("This maze seems very large, with each cell being nearly 10 horselengths long. *A horselength is 8 feet*")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
     X │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down\n")
    userInput = input()
    if userInput == "down":
      b2()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a3():
  directions = ["right"]
  print("There is a decayed enscription on the right wall. You look closer and find that it says \"disc-v--d a u-e--l s-st-- of magic fur--er t-sts ne-ded")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │ X                  │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right\n")
    userInput = input()
    if userInput == "right":
      a4()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a4():
  directions = ["right", "left"]
  print("You think you recognise this place but your mind goes blank")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │    X               │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/left\n")
    userInput = input()
    if userInput == "right":
      a5()
    elif userInput == "left":
      a3()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a5():
  directions = ["left", "down", "right"]
  print("You are at a three way. not much else")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │       X            │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/down/left\n")
    userInput = input()
    if userInput == "left":
      a4()
    elif userInput == "down":
      b5()
    elif userInput == "right":
      a6
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a6():
  directions = ["right", "left"]
  print("You look at how tall the walls of the maze are and wonder how far you fell when you entered the maze")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │          X         │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/left\n")
    userInput = input()
    if userInput == "right":
      a7()
    elif userInput == "left":
      a5()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a7():
  directions = ["right", "left"]
  print("You think about how the map might have lead you into a trap")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │            X       │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/left\n")
    userInput = input()
    if userInput == "right":
      a8()
    elif userInput == "left":
      a6()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a8():
  directions = ["right", "left"]
  print("You think you hear whispers from the wall next to you")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                X   │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/left\n")
    userInput = input()
    if userInput == "right":
      a9()
    elif userInput == "left":
      a7()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a9():
  directions = ["left", "down"]
  print("there seems to be a hallway on the near side of the opposite wall")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                  X │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down\n")
    userInput = input()
    if userInput == "left":
      a8()
    elif userInput == "down":
      b9()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def a10():
  directions = ["down"]
  print("There is a faded enscryption on the wall. \"Magic pro-uces a s--ll bla-k fog a- a byp---uct\"")
  from main import slow_print
  from mine import inventory
  from mine import glasses  
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │ X│
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down\n")
    userInput = input()
    if userInput == "down":
      b10()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def b1():
  directions = ["down", "right"]
  print("You feel like you are very close to the entrance")
  from main import slow_print
  from mine import inventory
  from mine import glasses  
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │ X      │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/down\n")
    userInput = input()
    if userInput == "right":
      b2()
    elif userInput == "down":
      c1()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b2():
  directions = ["left", "right", "up"]
  print("You aren't very far from the entrance. Worried you might get lost")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │    X   │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up/right\n")
    userInput = input()
    if userInput == "left":
      b1()
    elif userInput == "right":
      b3()
    elif userInput == "up":
      a2()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b3():
  directions = ["left", "down"]
  print("As you go deeper and deeper you notice that the darkness is disapating.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │      X │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down\n")
    userInput = input()
    if userInput == "left":
      b2()
    elif userInput == "down":
      c3()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b4():
  directions = ["right", "down"]
  print("The darkness is thinner but it is still there")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │ X   │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/down\n")
    userInput = input()
    if userInput == "right":
      b5()
    elif userInput == "down":
      c4()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b5():
  directions = ["left", "up"]
  print("You feel like you have been lost for an eternity.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │   X │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up\n")
    userInput = input()
    if userInput == "left":
      b3()
    elif userInput == "up":
      a5()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b6():
  directions = ["right", "down"]
  print("As you pass by a mossy section of wall you wonder how long this maze has been here.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │ X   │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/down\n")
    userInput = input()
    if userInput == "right":
      b7()
    elif userInput == "down":
      c6()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b7():
  directions = ["left", "down"]
  print("You come across a more broken section of wall and can see to the other side. You cannot crawl through")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │   X │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down\n")
    userInput = input()
    if userInput == "left":
      b6()
    elif userInput == "down":
      c7()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b8():
  directions = ["right"]
  print("There is a small hole in the wall which allows you to see through. There is a small pouch with 100 coins inside")
  from mine import coins
  coins += 100
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │ X   │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right\n")
    userInput = input()
    if userInput == "right":
      b9()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b9():
  directions = ["left", "up"]
  print("You think about how the shopkeepers face looked like a well fabricated mask")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │   X │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up\n")
    userInput = input()
    if userInput == "left":
      b8()
    elif userInput == "up":
      a9()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def b10():
  directions = ["up", "down"]
  print("\"This is a long hallway\" the map cheerfully remarks")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │ X│
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down/up\n")
    userInput = input()
    if userInput == "up":
      a10()
    elif userInput == "down":
      c10
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def c1():
  directions = ["down", "up"]
  print("You are in a long wide corridor")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │ X│  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down/up\n")
    userInput = input()
    if userInput == "down":
      d1()
    elif userInput == "up":
      b1()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c2():
  directions = ["down"]
  print("You find a single coin on the ground with special markings. You pick it up.")
  from mine import inventory
  inventory.append("coin of death")
  coins += 1
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │X │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down\n")
    userInput = input()
    if userInput == "down":
      d2()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c3():
  directions = ["right", "up"]
  print("The map speaks of all the adventures it has had.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │ X         │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/up\n")
    userInput = input()
    if userInput == "right":
      c4()
    elif userInput == "up":
      b3()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c4():
  directions = ["left", "up", "right"]
  print("You hear water dripping off of stalactites")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │   X       │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up/right\n")
    userInput = input()
    if userInput == "left":
      c3()
    elif userInput == "up":
      b4()
    elif userInput == "right":
      c5()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c5():
  directions = ["left", "right"]
  print("You get the foreboding feeling you've been here before")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │      X    │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/right\n")
    userInput = input()
    if userInput == "left":
      c4()
    elif userInput == "right":
      c6()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c6():
  directions = ["left", "up", "down"]
  print("You wonder how you'll ever escape")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │         X │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up/down\n")
    userInput = input()
    if userInput == "left":
      c5()
    elif userInput == "up":
      b6()
    elif userInput == "down":
      d6()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c7():
  directions = ["right", "up"]
  print("You wonder what could've caused the hole in the wall near you")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │ X      │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/up\n")
    userInput = input()
    if userInput == "right":
      c8()
    elif userInput == "up":
      b7()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c8():
  directions = ["left", "right"]
  print("You feel as if the darkness is much thinner deeper in.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │    X   │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up\n")
    userInput = input()
    if userInput == "left":
      c7()
    elif userInput == "right":
      c9()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c9():
  directions = ["left", "down"]
  print("you hear water dripping from the ceiling high above")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │      X │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down\n")
    userInput = input()
    if userInput == "left":
      c8()
    elif userInput == "down":
      d9()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def c10():
  directions = ["down", "up"]
  print("You wonder how many people have traversed this maze")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │X │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down/up\n")
    userInput = input()
    if userInput == "down":
      d10()
    elif userInput == "up":
      b10()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def d1():
  directions = ["down", "up"]
  print("When will you find the way out... if ever")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │ X│           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down/up\n")
    userInput = input()
    if userInput == "down":
      e1()
    elif userInput == "up":
      c1()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d2():
  directions = ["right", "up"]
  print("The darkness is nearly nonexistent now")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │ X         │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/up\n")
    userInput = input()
    if userInput == "right":
      d3()
    elif userInput == "up":
      c2()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d3():
  directions = ["left", "right"]
  print("You feel a foreboding presence")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │    X      │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/right\n")
    userInput = input()
    if userInput == "left":
      d2()
    elif userInput == "right":
      d4()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d4():
  directions = ["left", "right"]
  print("The map mumbles softly")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │      X    │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/right\n")
    userInput = input()
    if userInput == "left":
      d3()
    elif userInput == "right":
      d5()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d5():
  directions = ["left", "down"]
  print("You hear a skuttering noise")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │         X │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down\n")
    userInput = input()
    if userInput == "left":
      d4()
    elif userInput == "down":
      e5()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d6():
  directions = ["down", "up"]
  print("You feel you are close to a holy presence")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │ X│     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down/up\n")
    userInput = input()
    if userInput == "down":
      e6()
    elif userInput == "up":
      c6()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d7():
  directions = ["right"]
  print("another dead end...")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │ X   │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right\n")
    userInput = input()
    if userInput == "right":
      d8
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d8():
  directions = ["left", "down"]
  print("You wonder why certain objects can talk")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │   X │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down\n")
    userInput = input()
    if userInput == "left":
      d7()
    elif userInput == "down":
      e8()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d9():
  directions = ["right", "up"]
  print("You wonder why this maze is so big")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │X    │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/up\n")
    userInput = input()
    if userInput == "right":
      d10()
    elif userInput == "up":
      c9()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def d10():
  directions = ["left", "up", down]
  print("You see a small enscryption worn by time. it is illegible")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │   X │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up/down\n")
    userInput = input()
    if userInput == "left":
      d9()
    elif userInput == "up":
      c10()
    elif userInput == "down":
      e10()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def e1():
  directions = ["right", "up", "down"]
  print("You wonder how you got here. You seem to be phasing through different planes of existence. The multiverse.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │ X         │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/up/down\n")
    userInput = input()
    if userInput == "right":
      e2()
    elif userInput == "up":
      d1()
    elif userInput == "down":
      f1()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e2():
  directions = ["left", "down", "right"]
  print("You hear demonic whispering from the wall near you")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │   X       │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down/right\n")
    userInput = input()
    if userInput == "left":
      e1()
    elif userInput == "down":
      f2()
    elif userInput == "right":
      e3()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e3():
  directions = ["left", "right"]
  print("You try to think of your family but can't remember... WHY CAN'T YOU REMEMBER?")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │       X   │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/right\n")
    userInput = input()
    if userInput == "left":
      e2()
    elif userInput == "right":
      e4()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e4():
  directions = ["left", "down"]
  print("Why must my masters always take this maze and noth the secret passage *the map remarks*")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │         X │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down\n")
    userInput = input()
    if userInput == "left":
      e3()
    elif userInput == "down":
      f4()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e5():
  directions = ["down", "up"]
  print("You feel a drop of water fall on your shoulder and look up. The maze is 150 horselengths tall *The map remarks*")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │X │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down/up\n")
    userInput = input()
    if userInput == "down":
      f5()
    elif userInput == "up":
      d5()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e6():
  directions = ["right", "up"]
  print("The darkness is incredibly thin as you feel you are getting closer to something it hates")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │ X   │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/up\n")
    userInput = input()
    if userInput == "right":
      e7()
    elif userInput == "up":
      d6()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e7():
  directions = ["left", "down"]
  print("You see a dead rat on the floor.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │   X │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/down\n")
    userInput = input()
    if userInput == "left":
      e6()
    elif userInput == "down":
      f7()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e8():
  directions = ["right", "up"]
  print("As you go towards the bottom right of the maze you realise that the darkness is getting much thinner as if it doesn't like something in that direction.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │ X      │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: right/up\n")
    userInput = input()
    if userInput == "right":
      e9()
    elif userInput == "up":
      d8()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e9():
  directions = ["left", "right"]
  print("You start humming a song you don't recognise")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │    X   │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/right\n")
    userInput = input()
    if userInput == "left":
      e8()
    elif userInput == "right":
      e10()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def e10():
  directions = ["left", "up"]
  print("You wonder if you should check the hall again.")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │      X │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up\n")
    userInput = input()
    if userInput == "left":
      e9()
    elif userInput == "up":
      d10()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")

def f1():
  directions = ["down", "up"]
  print("You don't know why you are here")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │X │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: down/up\n")
    userInput = input()
    if userInput == "down":
      g1()
    elif userInput == "up":
      e1()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def f2():
  directions = ["right", "up"]
  print("There is a very small inscryption on the wall... Nothing is as it seems")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │ X   │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up\n")
    userInput = input()
    if userInput == "right":
      f3()
    elif userInput == "up":
      e2()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
def f3():
  directions = ["left", "up"]
  print("The foreboding presence strengthens as you go downward. It feels... misty")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │   X │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up\n")
    userInput = input()
    if userInput == "left":
      tallroom()
    elif userInput == "up":
      traproom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")
#def f4():
#def f5():
#def f6():
#def f7():
#def f8():
#def f9():
#def f10():

#def g1():
#def g2():
#def g3():
#def g4():
#def g5():
#def g6():
#def g7():
#def g8():
#def g9():
#def g10():


  directions = ["left", "up"]
  print("LORE MUMBO JUMBO")
  from main import slow_print
  from mine import inventory
  from mine import glasses
  if "glasses" in inventory:
    print("""───────┬────────────────────┬──┐
       │                    │  │
─┬───  └──┬───  ┌─────┬──┐  │  │
 │        │     │     │     │  │
 │  ┌──┐  │  ───┘  │  └─────┤  │
 │  │  │           │        │  │
 │  │  └────────┐  ├─────┐  │  │
 │  │           │  │     │     │
 │  └────────┐  │  └──┐  └──┤  │
 │           │  │     │        │
 │  │  ───┐  │  ├───  ├────────┤
 │  │     │  │  │     │        │
 │  └──┐  └──┘  │  ───┘  ┌───  │
 │     │        │        │     │
 └─────┴────────┴────────┴   ──┘\n""")
  userInput = ""
  while userInput not in directions:
    slow_print("Options: left/up\n")
    userInput = input()
    if userInput == "left":
      tallroom()
    elif userInput == "up":
      traproom()
    else: 
      slow_print("Please enter a valid option for the adventure game.\n")